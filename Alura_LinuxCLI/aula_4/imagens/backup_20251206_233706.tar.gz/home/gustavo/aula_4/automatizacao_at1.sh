#! /bin/bash

# 1. Comandos para atualizar os pacotes do sistema operacional
sudo apt update -y
sudo apt upgrade -y
